const Settings = () => {
  return (
    <div>
      settings page
      <p>Settings will be available soon.</p>
    </div>
  );
};

export default Settings;
