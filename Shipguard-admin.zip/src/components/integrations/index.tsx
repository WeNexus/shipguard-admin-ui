const Integrations = () => {
  return (
    <div>
      integrations page
      <p>Integrations will be available soon.</p>
    </div>
  );
};

export default Integrations;
