// export const BASE_URL =
//   " https://journal-julie-breakdown-strips.trycloudflare.com";

export const BASE_URL = "https://shipguard.app";
